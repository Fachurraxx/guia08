package frsf.isi.died.guia08.problema01;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppRRHHTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
