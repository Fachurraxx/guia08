package frsf.isi.died.guia08.problema01.modelo;

import static org.junit.Assert.*;

import org.junit.Test;

public class TareaTest {

	@Test
	public void asignarEmpleadoTest() {
		fail("Not yet implemented");
	}

}
