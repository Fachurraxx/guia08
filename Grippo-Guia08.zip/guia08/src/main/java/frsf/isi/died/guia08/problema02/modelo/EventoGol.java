package frsf.isi.died.guia08.problema02.modelo;

public class EventoGol extends Evento {

	private Jugador jugadorMarco;
	private Jugador jugadorAsistio;
	private boolean GolEnContra;
	
	
	public Jugador getJugadorMarco() {
		return jugadorMarco;
	}
	public void setJugadorMarco(Jugador jugadorMarco) {
		this.jugadorMarco = jugadorMarco;
	}
	public Jugador getJugadorAsistio() {
		return jugadorAsistio;
	}
	public void setJugadorAsistio(Jugador jugadorAsistio) {
		this.jugadorAsistio = jugadorAsistio;
	}
	public boolean isGolEnContra() {
		return GolEnContra;
	}
	public void setGolEnContra(boolean golEnContra) {
		GolEnContra = golEnContra;
	}
	
	
}
