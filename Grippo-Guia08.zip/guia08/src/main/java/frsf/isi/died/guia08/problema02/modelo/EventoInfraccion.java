package frsf.isi.died.guia08.problema02.modelo;

public class EventoInfraccion extends Evento {

	private Jugador jugadorCometio;
	private Jugador jugadorRecibio;
	public Jugador getJugadorCometio() {
		return jugadorCometio;
	}
	public void setJugadorCometio(Jugador jugadorCometio) {
		this.jugadorCometio = jugadorCometio;
	}
	public Jugador getJugadorRecibio() {
		return jugadorRecibio;
	}
	public void setJugadorRecibio(Jugador jugadorRecibio) {
		this.jugadorRecibio = jugadorRecibio;
	}
	
	
	
}
