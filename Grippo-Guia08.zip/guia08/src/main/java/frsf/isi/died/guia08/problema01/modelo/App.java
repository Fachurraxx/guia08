package frsf.isi.died.guia08.problema01.modelo;

import java.io.IOException;
import java.time.LocalDateTime;

import frsf.isi.died.guia08.problema01.AppRRHH;

public class App {

	
	public static void main(String[] args) {
		
		AppRRHH a = new AppRRHH();
		TareaCsv textoTareas = new TareaCsv();
		
		a.agregarEmpleadoContratado(7, "ramiro" , 10.00);
		a.agregarEmpleadoEfectivo(8, "rama" , 10.00);
		a.agregarEmpleadoContratado(1, "ramiro 2" , 100.00);
		a.agregarEmpleadoEfectivo(28, "rama 2" , 100.00);
		
		/*for(Empleado e : a.getEmpleados()) {
			System.out.println(e.getNombre());
		}*/
		
		try {
			a.asignarTarea(7, 1, "Tarea 1", 28);
			a.asignarTarea(8, 2, "Tarea 2", 5);
			
			a.asignarTarea(7, 5, "Tarea 2", 5);

			a.asignarTarea(1, 3, "Tarea 3", 7);
			a.asignarTarea(28, 4, "Tarea 4", 1);
		} catch (AsignarTareaException e1) {
			e1.printStackTrace();
		}
		
		try {
			a.empezarTarea(7,1);
			a.empezarTarea(8,2);
			a.empezarTarea(1,3);
			a.empezarTarea(28,4);
			
			a.terminarTarea(7,1);
			
		} catch (TareaNoEncontradaException e1) {
			e1.printStackTrace();
		}
		
		//a.imprimirEmpleadosCuil();
		
		Tarea t1 = new Tarea (1, "Tarea 1", 5 , LocalDateTime.now() , false);
		try {
			textoTareas.guardar(t1);
			System.out.println( textoTareas.cargar(t1.getId()).toString() );
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
}
