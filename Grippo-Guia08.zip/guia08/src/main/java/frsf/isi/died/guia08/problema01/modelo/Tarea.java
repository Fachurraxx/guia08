package frsf.isi.died.guia08.problema01.modelo;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.function.Predicate;

public class Tarea {

	private Integer id;
	private String descripcion;
	private Integer duracionEstimada;
	private Empleado empleadoAsignado;
	private LocalDateTime fechaInicio;
	private LocalDateTime fechaFin;
	private Boolean facturada;
	
	private Predicate<Tarea> puedeAsignarTarea = t -> (t.getEmpleadoAsignado() == null && t.getFechaFin() == null);
	
	public Tarea(int idtarea, String desc, int dur, LocalDateTime date, boolean fac) {
		this.id = idtarea;
		this.descripcion = desc;
		this.duracionEstimada = dur;
		this.fechaInicio = date;
		this.facturada = fac;
		this.empleadoAsignado = null;
		this.fechaFin = null;
		this.fechaInicio = null;
	}
	
	public Tarea() {
		
	}

	public void asignarEmpleado(Empleado e) throws AsignarTareaException {
		
		if(puedeAsignarTarea.test(this)) {
			this.empleadoAsignado = e;
			}
		else 
			throw new AsignarTareaException("No se puede asignar el empleado " + e.getNombre().toString()+ " a esta tarea");		
	
	}

	
	public String asCsv() {
		return this.getId() + ";\" "+ this.getDescripcion() + "\";"+ this.getDuracionEstimada(); // + "\";" + this.getEmpleadoAsignado().getCuil();
	} 
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Integer getDuracionEstimada() {
		return duracionEstimada;
	}

	public void setDuracionEstimada(Integer duracionEstimada) {
		this.duracionEstimada = duracionEstimada;
	}

	public LocalDateTime getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(LocalDateTime fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public LocalDateTime getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(LocalDateTime fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Boolean getFacturada() {
		return facturada;
	}

	public void setFacturada(Boolean facturada) {
		this.facturada = facturada;
	}

	public Empleado getEmpleadoAsignado() {
		return empleadoAsignado;
	}
	
	@Override
	public String toString() {
		return "Tarea: " + id +" "+this.descripcion+ " - Fecha inicio: " + this.getDuracionEstimada();
		
	}
}
