package frsf.isi.died.guia08.problema01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import frsf.isi.died.guia08.problema01.modelo.AsignarTareaException;
import frsf.isi.died.guia08.problema01.modelo.Empleado;
import frsf.isi.died.guia08.problema01.modelo.Tarea;
import frsf.isi.died.guia08.problema01.modelo.TareaNoEncontradaException;
import frsf.isi.died.guia08.problema01.modelo.Empleado.Tipo;

public class AppRRHH {

	private List<Empleado> empleados;
	
	public AppRRHH() {
		this.empleados = new ArrayList<Empleado>();
	} 	


	public void agregarEmpleadoContratado(Integer cuil,String nombre,Double costoHora) {
		Empleado e = new Empleado(cuil, nombre, Tipo.CONTRATADO ,costoHora);
		empleados.add(e);
	}
	
	public void agregarEmpleadoEfectivo(Integer cuil,String nombre,Double costoHora) {
		Empleado e = new Empleado(cuil, nombre, Tipo.EFECTIVO ,costoHora);
		empleados.add(e);	
	}
	
	public void asignarTarea(Integer cuil,Integer idTarea,String descripcion,Integer duracionEstimada) throws AsignarTareaException {
		
		Optional<Empleado> e1 = buscarEmpleado(e -> e.getCuil() == cuil);
			
		if(e1.isPresent()) {
			Tarea t1 = new Tarea(idTarea, descripcion, duracionEstimada, LocalDateTime.now() , false);
			e1.get().asignarTarea(t1);
		}
	
	}
	
	public void empezarTarea(Integer cuil,Integer idTarea) throws TareaNoEncontradaException {
		
		Optional<Empleado> e1 = buscarEmpleado(e -> e.getCuil() == cuil);
		e1.get().comenzar(idTarea);
	}
	
	public void terminarTarea(Integer cuil,Integer idTarea) throws TareaNoEncontradaException {
		Optional<Empleado> e1 = buscarEmpleado(e -> e.getCuil() == cuil);
		e1.get().finalizar(idTarea);
	}

	public void imprimirEmpleadosCuil() {
		
	List <Empleado> e = this.empleados
						.stream()
						.sorted( (e1,e2)-> e1.getCuil().compareTo(e2.getCuil()) )
						.collect(Collectors.toList());	

	for(Empleado emp : e) {
		
		System.out.println("Empleado: " + emp.getNombre().toString());
		emp.imprimirTareasAsignadas();
	}
		
	}
	
	
	public void cargarEmpleadosContratadosCSV(String nombreArchivo) throws FileNotFoundException, IOException  {
		
		FileInputStream fis;
		try(Reader fileReader = new FileReader(nombreArchivo+".csv")){
			try(BufferedReader in = new BufferedReader(fileReader)){
				String linea = null;
				while((linea = in.readLine())!=null) {
					String[] fila = linea.split(";");
							
					Optional<Empleado> e1 = buscarEmpleado(e -> e.getCuil() == Integer.valueOf(fila[0]));
					if(e1.isPresent() && e1.get().getTipo() == Tipo.CONTRATADO ) {
		
							this.agregarEmpleadoContratado(Integer.valueOf(fila[0]), fila[1], Double.valueOf(fila[2]));
					}
						
					}
				}
				
			}
	}

	public void cargarEmpleadosEfectivosCSV(String nombreArchivo) throws FileNotFoundException, IOException  {
			
			FileInputStream fis;
			try(Reader fileReader = new FileReader(nombreArchivo+".csv")){
				try(BufferedReader in = new BufferedReader(fileReader)){
					String linea = null;
					while((linea = in.readLine())!=null) {
						String[] fila = linea.split(";");
								
						Optional<Empleado> e1 = buscarEmpleado(e -> e.getCuil() == Integer.valueOf(fila[0]));
						if(e1.isPresent() && e1.get().getTipo() == Tipo.EFECTIVO ) {
			
								this.agregarEmpleadoEfectivo(Integer.valueOf(fila[0]), fila[1], Double.valueOf(fila[2]));
						}
							
						}
					}
					
				}	
	}

	public void cargarTareasCSV(String nombreArchivo) throws FileNotFoundException, IOException {
		
		FileInputStream fis;
		try(Reader fileReader = new FileReader(nombreArchivo+".csv")){
			try(BufferedReader in = new BufferedReader(fileReader)){
				String linea = null;
				while((linea = in.readLine())!=null) {
					String[] fila = linea.split(";");
					
							Tarea tnew = new Tarea();
							tnew.setId(Integer.valueOf(fila[0]));
							tnew.setDescripcion(fila[1]);
							tnew.setDuracionEstimada(Integer.valueOf(fila[2]));
							
							System.out.println( tnew.toString() );
						
					}
				}
				
			}
		}

	
	private void guardarTareasTerminadasCSV() throws IOException {
		
		try(Writer fileWriter = new FileWriter("tareas.csv",true)){
			try(BufferedWriter out = new BufferedWriter (fileWriter)){
				for(Empleado emp : empleados) {
					for(Tarea t : emp.getTareasAsignadas()) {
						if(!t.getFacturada() && t.getFechaFin() != null)
				out.write(t.asCsv() + System.getProperty("line.separator"));
			}
				}
			}
		}
	}
		
		// y el nombre y cuil del empleado que la finalizó en formato CSV 
	
	
	private Optional<Empleado> buscarEmpleado(Predicate<Empleado> p){
		return this.empleados.stream().
				filter(p).
				findFirst();
	}

	public Double facturar() {
		try {
			this.guardarTareasTerminadasCSV();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return this.empleados.stream()				
				.mapToDouble(e -> e.salario())
				.sum();
	}
	
	public List<Empleado> getEmpleados() {
		return empleados;
	}
	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}
}
