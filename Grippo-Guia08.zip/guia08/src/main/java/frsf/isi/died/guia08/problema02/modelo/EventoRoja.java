package frsf.isi.died.guia08.problema02.modelo;

public class EventoRoja extends Evento {

	private Jugador jugador;
	private String descripcion;
	
	public Jugador getJugador() {
		return jugador;
	}
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	
	
}
