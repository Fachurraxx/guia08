package frsf.isi.died.guia08.problema01.modelo;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Empleado {

	public enum Tipo { CONTRATADO,EFECTIVO}; 
	
	private Integer cuil;
	private String nombre;
	private Tipo tipo;
	private Double costoHora;
	private List<Tarea> tareasAsignadas;

	public Empleado(int nroCuil, String nom, Tipo t, double hor) {
		cuil = nroCuil;
		nombre = nom;
		tipo = t;
		costoHora = hor;
		this.tareasAsignadas = new ArrayList<Tarea>();
	}	
	
	public Empleado() {
	}

	public Double salario() {
		List<Tarea> tareasNoFacturadas = 
			 tareasAsignadas.stream()
							.filter( t-> t.getFacturada()== false )
							.filter(t -> t.getFechaFin() != null )
							.collect (Collectors.toList());
		
		for(Tarea tarea : tareasAsignadas) {
			tarea.setFacturada(true);
		}
		switch (tipo) {
		case CONTRATADO:
			return calcularCostoContratado(tareasNoFacturadas);
			
		case EFECTIVO: 
			return calcularCostoEfectivo(tareasNoFacturadas);
		
		default:
			return 0.0;
		}
	}
	
	public double calcularCostoEfectivo(List<Tarea> t) {
		double aumento = 0; 
		double salario = 0;
		
		for(Tarea tarea : t) {
			Duration tiempo = Duration.between(tarea.getFechaInicio(), tarea.getFechaFin());
			
			if((tiempo.toDays()*4) < tarea.getDuracionEstimada() ) {
			aumento = 0.20;		
			}
			salario += tarea.getDuracionEstimada()*(this.costoHora + this.costoHora * aumento);
		}
		
		
		return salario;
	}
	
	public double calcularCostoContratado(List<Tarea> t) {
		
	double aumento = 0; 
	double salario = 0;
	
	for(Tarea tarea : t) {
		Duration tiempo = Duration.between(tarea.getFechaInicio(), tarea.getFechaFin());
		
		if((tiempo.toDays()*4) < tarea.getDuracionEstimada() ) {
			aumento = 0.30;		
		}
		if((tiempo.toDays()*4)-tarea.getDuracionEstimada() > 8) {
			aumento = - 0.25;	
		}
		
		salario += tarea.getDuracionEstimada()*(this.costoHora + this.costoHora * aumento);
	}
		
		return salario;
	}
		
	public Boolean asignarTarea(Tarea t){
		
		switch (this.tipo) {
		case CONTRATADO: 
			if(this.tareasAsignadas.size() == 5) 
				return false;	
			else {
				try {
					t.asignarEmpleado(this);
					this.tareasAsignadas.add(t);
				} catch (AsignarTareaException e) {
					e.printStackTrace();
				}
				return true;
			}
			
		case EFECTIVO:
			if(!this.tareasAsignadas.isEmpty()|| t.getDuracionEstimada() > 15)
				return false;	
			else {
				try {
					t.asignarEmpleado(this);
					this.tareasAsignadas.add(t);
					return true;
				} catch (AsignarTareaException e) {
					e.printStackTrace();
				}
			}
		default: 
			return false;
		}
	}
	
	Optional<Tarea> buscarPorId(Integer id){
		
		for(Tarea tarea : tareasAsignadas) {
			if(tarea.getId().equals(id)) 
				return Optional.of(tarea);
		}
		return Optional.empty();	
	}
	 
	public void comenzar(Integer idTarea) throws TareaNoEncontradaException {
		buscarPorId(idTarea).orElseThrow(
				() -> new TareaNoEncontradaException("Tarea no encontrada")
				).setFechaInicio(LocalDateTime.now());
	}
	

	public void finalizar(Integer idTarea) throws TareaNoEncontradaException{
		buscarPorId(idTarea).orElseThrow(
				() -> new TareaNoEncontradaException("Tarea no encontrada")
				).setFechaFin(LocalDateTime.now());
	}

	public void comenzar(Integer idTarea,String fecha) throws TareaNoEncontradaException{
		buscarPorId(idTarea).orElseThrow(
				() -> new TareaNoEncontradaException("Tarea no encontrada")
				).setFechaInicio(LocalDateTime.parse(fecha));
		
	}
	
	public void finalizar(Integer idTarea,String fecha) throws TareaNoEncontradaException{
		buscarPorId(idTarea).orElseThrow(
				() -> new TareaNoEncontradaException("Tarea no encontrada")
				).setFechaFin(LocalDateTime.parse(fecha));
	}

	//@Override
	public String asCsv() {
		return this.getCuil() + ";\" "+ this.getNombre() + "\";"+ this.getCostoHora();
	}
	
	public Integer getCuil() {
		return cuil;
	}

	public void setCuil(Integer cuil) {
		this.cuil = cuil;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public Double getCostoHora() {
		return costoHora;
	}

	public void setCostoHora(Double costoHora) {
		this.costoHora = costoHora;
	}

	public List<Tarea> getTareasAsignadas() {
		return tareasAsignadas;
	}

	public void setTareasAsignadas(List<Tarea> tareasAsignadas) {
		this.tareasAsignadas = tareasAsignadas;
	}

	public void imprimirTareasAsignadas() {
		
		for(Tarea t : tareasAsignadas) {
			
			String id = Integer.toString(t.getId());
			System.out.println("Tarea: " + id + " - Fecha inicio: " + t.getFechaInicio().toString());
		}
			
	}
	
	 @Override
	 public String toString() {
	return "Empleado: " + this.getCuil() +" "+ this.getNombre() + ". CostoXHora: " + this.getCostoHora();	 
		 }
	
}
