package frsf.isi.died.guia08.problema02.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Partido {

	private Equipo local;
	private Equipo visitante;
	private List<Evento> eventos;
	private LocalDateTime dia;
	
	public void addEvento(Evento e) {
		if(this.eventos ==null) this.eventos = new ArrayList<Evento>();
		this.eventos.add(e);
	}
	
	public List<Evento> getEventos() {
		return eventos;
	}


	public Integer golesLocal() {
		int contador = 0;
		
		for(Evento evento : eventos) {
			//recorro eventos que son goles
			if (evento instanceof EventoGol) {
				//sumo los goles que hizo un jugador del equipo local y q no fue en contra
				if( local.getPlantel().contains(((EventoGol) evento).getJugadorMarco()) &&
						!((EventoGol) evento).isGolEnContra() ) {
					contador += 1;
				}
				//sumo los goles que hizo un jugador del equipo visistante y que fue en contra
				if( visitante.getPlantel().contains(((EventoGol) evento).getJugadorMarco()) &&
						((EventoGol) evento).isGolEnContra() ) {
					contador += 1;
				}
				
			}
		}
		//retorno los goles contados
		return contador;
	}

	public Integer golesVisitante() {
		
		long e = eventos.stream()
						.filter(l-> l instanceof EventoGol)
						.filter(l ->  local.getPlantel().contains(((EventoGol) l).getJugadorMarco()) )
						.count();
		
		return 0;
	}

	
	
	public Integer golesPuntosLocal() {
		return 0;
	}

	public Integer golesPuntosVisitante() {
		return 0;
	}

	
	
	public Equipo getLocal() {
		return local;
	}

	public void setLocal(Equipo local) {
		this.local = local;
	}

	public Equipo getVisitante() {
		return visitante;
	}

	public void setVisitante(Equipo visitante) {
		this.visitante = visitante;
	}


	public LocalDateTime getDia() {
		return dia;
	}


	public void setDia(LocalDateTime dia) {
		this.dia = dia;
	}


	public void setEventos(List<Evento> eventos) {
		this.eventos = eventos;
	}

	
}
