package frsf.isi.died.guia08.problema01.modelo;

public class TareaNoEncontradaException extends Exception {

	public TareaNoEncontradaException(String mensaje) {
		super(mensaje);
	}
	
}
