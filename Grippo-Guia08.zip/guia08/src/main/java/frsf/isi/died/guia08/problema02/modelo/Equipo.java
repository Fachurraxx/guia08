package frsf.isi.died.guia08.problema02.modelo;

import java.util.List;

public class Equipo {

	private String nombre;
	private List<Jugador> plantel;
	private List<Partido> partidosJugados;
	
	public Integer puntos() {
		return 0;
	}
	
	

	public Integer partidosGanados() {
		return 0;
	}



	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public List<Jugador> getPlantel() {
		return plantel;
	}



	public void setPlantel(List<Jugador> plantel) {
		this.plantel = plantel;
	}



	public List<Partido> getPartidosJugados() {
		return partidosJugados;
	}



	public void setPartidosJugados(List<Partido> partidosJugados) {
		this.partidosJugados = partidosJugados;
	}

	
}
