package frsf.isi.died.guia08.problema01.modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;


//Prototipo para aprender como guardar y cargar en archivo csv


public class TareaCsv {

	public void guardar(Tarea t) throws IOException {
		
		try(Writer fileWriter = new FileWriter("tareas.csv",true)){
			try(BufferedWriter out = new BufferedWriter (fileWriter)){
				out.write(t.asCsv() + System.getProperty("line.separator"));
			}
		}
	}
	
	public Tarea cargar(Integer id) throws FileNotFoundException, IOException{
		FileInputStream fis;
		try(Reader fileReader = new FileReader("tareas.csv")){
			try(BufferedReader in = new BufferedReader(fileReader)){
				String linea = null;
				while((linea = in.readLine())!=null) {
					String[] fila = linea.split(";");
						if(Integer.valueOf(fila[0]).equals(id)) {
							Tarea t = new Tarea();
							t.setId(Integer.valueOf(fila[0]));
							t.setDescripcion(fila[1]);
							t.setDuracionEstimada(Integer.valueOf(fila[2]));
							return t;
						}
				}
				
			}
		}
		
		return null;
	}
	
	
}
