package frsf.isi.died.guia08.problema02;

import java.util.List;

import frsf.isi.died.guia08.problema02.modelo.Equipo;
import frsf.isi.died.guia08.problema02.modelo.Fecha;

public class LigaApp {

	private List<Fecha> calendario;
	private List<Equipo> equipos;
	
}
