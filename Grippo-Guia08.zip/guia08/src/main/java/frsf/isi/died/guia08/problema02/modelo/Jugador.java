package frsf.isi.died.guia08.problema02.modelo;

import java.time.LocalDateTime;

public class Jugador {

	private enum Posicion{ARQUERO,DEFENSOR,MEDIOCAMPISTA,DELANTERO};
	private enum Pierna {DERECHA,IZQUIERDA};
	private String nombre;
	private String apellido;
	private LocalDateTime fechaNac;
	private Posicion posicion;
	private float altura;
	private float peso;
	private Pierna pierna;

	
	public Jugador(String nom, String ap, LocalDateTime fec, 
			Posicion pos, float a, float p, Pierna pie) {
		
		nombre = nom;
		apellido = ap;
		fechaNac = fec;
		posicion = pos;
		altura = a;
		peso = p;
		pierna = pie;
		
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public LocalDateTime getFechaNac() {
		return fechaNac;
	}


	public void setFechaNac(LocalDateTime fechaNac) {
		this.fechaNac = fechaNac;
	}


	public Posicion getPosicion() {
		return posicion;
	}


	public void setPosicion(Posicion posicion) {
		this.posicion = posicion;
	}


	public float getAltura() {
		return altura;
	}


	public void setAltura(float altura) {
		this.altura = altura;
	}


	public float getPeso() {
		return peso;
	}


	public void setPeso(float peso) {
		this.peso = peso;
	}


	public Pierna getPierna() {
		return pierna;
	}


	public void setPierna(Pierna pierna) {
		this.pierna = pierna;
	}
	
	
	
}
