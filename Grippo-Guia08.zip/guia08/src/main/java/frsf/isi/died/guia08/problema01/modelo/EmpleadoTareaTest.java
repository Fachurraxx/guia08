package frsf.isi.died.guia08.problema01.modelo;

import java.time.LocalDateTime;

import frsf.isi.died.guia08.problema01.modelo.Empleado.Tipo;
import junit.framework.TestCase;

public class EmpleadoTareaTest extends TestCase {
	
	private Empleado emp1;
	private Empleado emp2;
	private Empleado emp3;
	private Empleado emp4;
	
	private Tarea t1;
	private Tarea t2;
	private Tarea t3;
	private Tarea t4;
	private Tarea t5;
	private Tarea t6;
	
	public void inicializar() {
		emp1 = new Empleado(1, "Ramiro", Tipo.CONTRATADO, 100);
		emp2 = new Empleado(2, "Juan", Tipo.CONTRATADO, 50);
		emp3 = new Empleado(3, "Martin", Tipo.EFECTIVO, 100);
		emp4 = new Empleado(4, "Lucas", Tipo.EFECTIVO, 50);
		
		t1 = new Tarea(1, "Tarea 1", 10 ,LocalDateTime.now(), false);
		t2 = new Tarea(2, "Tarea 2", 15 ,LocalDateTime.now(), false);
		t3 = new Tarea(3, "Tarea 3", 20 ,LocalDateTime.now(), false);
		t4 = new Tarea(4, "Tarea 4", 30 ,LocalDateTime.now(), false);
		t5 = new Tarea(4, "Tarea 5", 30 ,LocalDateTime.now(), false);
		t6 = new Tarea(4, "Tarea 6", 30 ,LocalDateTime.now(), false);
	}
	
	public void testAsignarTareaContratado() {
		inicializar();
		assertTrue(emp1.asignarTarea(t1));
		assertTrue(emp1.asignarTarea(t2));
		assertTrue(emp1.asignarTarea(t3));
		assertTrue(emp1.asignarTarea(t4));
		assertTrue(emp1.asignarTarea(t5));
		assertFalse(emp1.asignarTarea(t6)); //Un empleado contratado no puede tener mas de 5 tareas
		
	}
	
	public void testAsignarTareaEfectivo() {
		inicializar();
		assertFalse(emp3.asignarTarea(t3)); //Un empleado efectivo no puede tener tareas con duracion mayor que 15
		assertTrue(emp3.asignarTarea(t1));
		assertFalse(emp3.asignarTarea(t2)); // Un empleado efectivo no puede tener una tarea ya asignada
	}
	
	public void testAsignarEmpleado(){
			inicializar();	
			try {
				t3.asignarEmpleado(emp1);
				assertTrue(t3.getEmpleadoAsignado() != null);
			//	t3.asignarEmpleado(emp1); //Lanza excepcion porque ya hay un empleado asignado a esa tarea	
			} catch (AsignarTareaException e) {
				e.printStackTrace();
			} 		
	}
	
	public void testComenzarYFinalizarTarea(){
		inicializar();
		try {
			emp1.asignarTarea(t1);
			assertTrue(t1.getFechaInicio() == null); //Tarea no comenzada
			assertTrue(t1.getFechaFin() == null);	// Tarea no finalizada
			emp1.comenzar(t1.getId());
			emp1.finalizar(t1.getId());
			assertTrue(t1.getFechaInicio() != null); //Tarea comenzada
			assertTrue(t1.getFechaFin() != null);	//Tarea Finalizada
			
		//	emp1.comenzar(t2.getId()); // Lanza una excepcion porque la tarea 2 no esta asignada al empleado 1
		//	emp1.finalizar(t2.getId()); // Lanza una excepcion porque la tarea 2 no esta asignada al empleado 1
			
		} catch (TareaNoEncontradaException e) {
			e.printStackTrace();
		}
		
		
	}
}
