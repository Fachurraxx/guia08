package frsf.isi.died.guia08.problema02.modelo;

public class EventoTiroDeEsquina extends Evento {

	private Jugador jugador;
	private enum lado {DERECHO,IZQUIERDO}
	
	
	public Jugador getJugador() {
		return jugador;
	}
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	};
	
	
	
}
